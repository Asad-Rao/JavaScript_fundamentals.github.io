// Declarig  a variable
// Assigning value to the nameofvariable
// Following code creates a real varaible in computer memory
// Value will be stored in nameofvariable
// Name varaible in camelcasing form
// Variables names cannot start with a number
// Variable name can only contain number , letters,under-score or dollar sign
// Do not use reserved key words in naming variables like new, function,name
//Do not start variable name with upper case letter like Person
//Variable name must be descriptive
let nameofvariable = 'Value';
// Variables that are all in upper case  are reserved for constants and constants
// will never change like number PI
let PI = 3.1415;

let county = 'Pakistan';
let continent = 'South Asia';
let population = 12000000000000000000000000000000000;
console.log(typeof population);
console.log(county, continent, population);
