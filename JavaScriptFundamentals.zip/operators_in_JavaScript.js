let birth_year = 2000;
let current_year = 2023;
// - is the mathematical operator
let age = current_year - birth_year;
console.log(current_year, birth_year, age);
let first_Name = 'Asad';
let last_Name = 'Khalil';
// + is an operator used for the concatenation
console.log(first_Name + ' ' + last_Name);
// then there is typeof operator which gives us the value

//**************************************Assignment Operators************************* */
// = is called the assignment operator
let x = 10 + 2;
// Following code is equivalent to x=x+10;
x += 10;
console.log('The value of x is ' + x);
// Following code means x=x*(-1)
x *= -1;
console.log('The value of x is ' + x);
// Following code means x=x/0
x /= 0;
console.log('The value of x is ' + x);

let y = -13;
// Following code means  y=y+1;
y++;
console.log('The value of y is ' + y);
// Following code means  y=y-1
y--;
console.log('The value of y is ' + y);

//**********************************COMPARISON OPERATORS*****************************/
console.log(3 < -1);
let age_comparison = age >= 22;
console.log(age_comparison);
