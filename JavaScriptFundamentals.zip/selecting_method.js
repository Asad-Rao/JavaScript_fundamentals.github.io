// Document is an Object
// querySelector() is a method
// In querySelector() method we need to pass in the selector
document.querySelector('.name_of_class');
