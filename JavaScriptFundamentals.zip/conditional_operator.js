let age = 23;
// After the ? we write the code that is to be executed when
// condition is evaluated as true
// After ? only one line of code can be writte
age >= 18
  ? console.log('Condition is True')
  : console.log('Condition is False');
