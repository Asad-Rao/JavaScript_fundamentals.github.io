// Push method
const name_of_array = ['A', 'B', 'C', 'D'];
// Push method
const value_returned_by_push_method = name_of_array.push('element_to_be_added');
console.log(value_returned_by_push_method);
console.log(name_of_array);
name_of_array.unshift('element_to_be_added_at_beginning');
console.log(name_of_array);
console.log(name_of_array.pop());
console.log(name_of_array);
console.log(name_of_array.shift());
console.log(name_of_array);
console.log(name_of_array.indexOf('B'));
