let input_fiedl_data = '1999';
console.log(typeof Number(input_fiedl_data));
console.log(typeof (input_fiedl_data + 10));
// Number build in funtion converts string data type to number data type
console.log(Number('string'));
console.log(typeof String(123));
console.log(typeof String(true));
console.log(typeof ('I am ' + 23 + 'years old' + true));
// JavaScript convert + 23 string to number
// JavaScript operator - convert 10 string to number
console.log('23' - '10' - 3);
// JavaScript Operator * converts string to number
console.log('23' * '2');
// JavaScript Operator / converts string to number
console.log('23' / '2');
// JavaScript Operator < converts string to number
console.log('32' < '95');
// JavaScript Operator <= converts string to number
console.log('32' <= '32');
