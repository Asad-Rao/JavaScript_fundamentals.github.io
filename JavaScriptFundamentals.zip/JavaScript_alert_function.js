// alert is a JavaScript function
// alert('Learning JavaScript');
let varaible = 'current value';
// updating the variable value
varaible = 'updated value';
console.log(varaible);
// Declarig  a variable
// Assigning value to the nameofvariable
// Following code creates a real varaible in computer memory
// Value will be stored in nameofvariable
// Name varaible in camelcasing form
// Variables names cannot start with a number
// Variable name can only contain number , letters,under-score or dollar sign
let nameofvariable = 'Value';
